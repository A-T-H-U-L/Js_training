class x{
constructor(name,age,add) {
    this.name=name;
    this.age=age;
    this.add=add;
    
};
}
var obj=new x("balaji",22,"banglore");
var arr=[];
arr.push(obj);
console.log(arr);